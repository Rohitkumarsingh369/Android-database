package com.example.singhmotors;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Salereport extends AppCompatActivity {
DataBaseHelper myDB2=new DataBaseHelper(this);
TextView sale1display,sale2display,sale3display,sale4display;
int count1=0,count2=0,count3=0,count4=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salereport);
            sale1display=findViewById(R.id.sale1);
        sale2display=findViewById(R.id.sale2);
        sale3display=findViewById(R.id.sale3);
        sale4display=findViewById(R.id.sale4);
        String [] texts={"Toyota-Fortuner", "Toyota-Innova", "Toyota-Land Cruiser", "Toyota-Prado"};
        Cursor res=myDB2.getData2();
        if(res!=null && res.getCount()>0){
            //You must move the cursor to the first item
            while(res.moveToNext()){
                    if(res.getString(3).equalsIgnoreCase(texts[0])){
                        count1=count1+1;
                    }
                if(res.getString(3).equalsIgnoreCase(texts[1])){
                    count2=count2+1;
                }
                if(res.getString(3).equalsIgnoreCase(texts[2])){
                    count3=count3+1;
                }
                if(res.getString(3).equalsIgnoreCase(texts[3])){
                    count4=count4+1;
                }
            }

        }
        else{
            Toast.makeText(this, "unsuccessfully", Toast.LENGTH_SHORT).show();
        }

        res.close();
        //String count11=Integer.toString(count1);
       sale1display.setText(Integer.toString(count1));
        sale2display.setText(Integer.toString(count2));
       sale3display.setText(Integer.toString(count3));
        sale4display.setText(Integer.toString(count4));

    }
}