package com.example.singhmotors;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Purchasedetails extends AppCompatActivity {
    EditText search;
    TextView name,num,model,date,time;
    Button searchbtn;
    RelativeLayout display;
DataBaseHelper myDB1=new DataBaseHelper(this);
   // @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchasedetails);

        search=findViewById(R.id.searchbox);
        searchbtn=findViewById(R.id.searchbutton);
        name=findViewById(R.id.namedisplay);
        num=findViewById(R.id.numberdisplay);
        model=findViewById(R.id.carmodeldisplay);
        date=findViewById(R.id.datedisplay);
        time=findViewById(R.id.timedisplay);
        display=findViewById(R.id.displaylayout);

        //Relativelayout invisibile
        display.setVisibility(View.INVISIBLE);

        searchbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getdata();
            }
        });
    }
    private void getdata(){

        String searchtext=search.getText().toString();
        Cursor res=myDB1.getData(searchtext);
        if(res!=null && res.getCount()>0){
            //You must move the cursor to the first item
            display.setVisibility(View.VISIBLE);
            name.setText(res.getString(1).substring(0,1).toUpperCase()+res.getString(1).substring(1).toLowerCase());
            num.setText(res.getString(2));
            model.setText(res.getString(3));
            date.setText(res.getString(4));
            time.setText(res.getString(5));
            search.getText().clear();
        }
        else{
            Toast.makeText(this, "Data not found", Toast.LENGTH_SHORT).show();
        }

        res.close();
    }
}