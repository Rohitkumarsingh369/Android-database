package com.example.singhmotors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final  String DATABASE_NAME = "Singhmotorss.db";

    public static final  String TABLE_NAME = "Customerdetail";
    public static final  String COL_1 = "ID";
    public static final  String COL_2 = "NAME";
    public static final  String COL_3 = "MOBILE";
    public static final  String COL_4 = "MODEL";
    public static final  String COL_5 = "DATE";
    public static final  String COL_6 = "TIME";



    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLE_NAME+"(ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,MOBILE TEXT,MODEL TEXT,DATE TEXT,TIME TEXT)");
    }

    @Override
    /*public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    }*/
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String customername,String customernum,String model,String date,String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,customername);
        contentValues.put(COL_3,customernum);
        contentValues.put(COL_4,model);
        contentValues.put(COL_5,date);
        contentValues.put(COL_6,time);
        long result = db.insert(TABLE_NAME,null,contentValues);
       db.close();

        //To Check Whether Data is Inserted in DataBase
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getData( String searched){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE MOBILE ="+searched,null);
        res.moveToFirst();
        db.close();
        return res;

    }
    public Cursor getData2( ){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM "+TABLE_NAME,null);
        res.moveToFirst();
        db.close();
        return res;

    }
}
