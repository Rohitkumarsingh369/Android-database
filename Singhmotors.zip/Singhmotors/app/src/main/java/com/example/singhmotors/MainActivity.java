package com.example.singhmotors;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    DataBaseHelper myDB=new DataBaseHelper(this);
    Button date,time,submit,salereportbtn,purchasedetailbtn;
    EditText datetext,timetext,name,mobile;
    AutoCompleteTextView model;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.custname);
        mobile=findViewById(R.id.custnum);
        date=findViewById(R.id.datebtn);
        time=findViewById(R.id.timebtn);
        datetext=findViewById(R.id.date);
        timetext=findViewById(R.id.time);
        model=findViewById(R.id.carmodel);
        salereportbtn=findViewById(R.id.salereport);
        purchasedetailbtn=findViewById(R.id.detail);
        String [] texts={"Toyota-Fortuner", "Toyota-Innova", "Toyota-Land Cruiser", "Toyota-Prado"};
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,texts);
        model.setAdapter(adapter);
        submit=findViewById(R.id.submitbtn);

        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                ClickMe();
            }
        });
        salereportbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(),Salereport.class);
                startActivity(intent);
            }
        });

        purchasedetailbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(),Purchasedetails.class);
                startActivity(intent);
            }
        });
    }
    public void displaydate(View view){
        final Calendar c=Calendar.getInstance();
        final int mYear=c.get(Calendar.YEAR);
        final int mMonth=c.get(Calendar.MONTH);
        final int mDate=c.get(Calendar.DATE);
        DatePickerDialog datePickerDialog=new DatePickerDialog(MainActivity.this, R.style.PickerTheme, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayofmonth) {
                datetext.setText(dayofmonth+"/"+(month+1)+"/"+year);

            }
        },mYear,mMonth,mDate);
        datePickerDialog.show();
    }
    public void displaytime(View view){
        final Calendar c=Calendar.getInstance();
        final int mHour=c.get(Calendar.HOUR_OF_DAY);
        final int mMinute=c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog=new TimePickerDialog(MainActivity.this, R.style.PickerTheme, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                timetext.setText(hourOfDay+":"+minute);
            }
        },mHour,mMinute,false);
        timePickerDialog.show();
    }
    private void ClickMe(){

        String customername=name.getText().toString();
        String customernum=mobile.getText().toString();
        String carmodel=model.getText().toString();
        String date=datetext.getText().toString();
        String time=timetext.getText().toString();
        if(TextUtils.isEmpty(customername) && TextUtils.isEmpty(customernum) && TextUtils.isEmpty(carmodel) && TextUtils.isEmpty(date) && TextUtils.isEmpty(time)) {
            name.setError("Please enter your name");
            mobile.setError("Please enter your number");
            model.setError("Please car model");
            datetext.setError("Please enter date");
            timetext.setError("Please enter time");
            return;
        }

            //clear the text
        name.getText().clear();
        mobile.getText().clear();
        model.getText().clear();
        datetext.getText().clear();
        timetext.getText().clear();
        //calling the database
               Boolean result=myDB.insertData(customername,customernum,carmodel,date,time);

        if(result==true){
            Toast.makeText(this,"Data Inserted successfully",Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Data  Not Inserted successfully", Toast.LENGTH_SHORT).show();
        }
    }

}